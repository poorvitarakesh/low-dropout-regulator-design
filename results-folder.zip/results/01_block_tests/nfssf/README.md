# NFSSF (Negative-Feedback Source Follower) – DC Operating Point

Two operating-point screenshots of the NFSSF with its bias inputs (vbias1, vbias2) and Vg. Device operating values (id, vgs, vds, gm) are annotated on the schematics.

![DC operating point A](dc_op_point_a.png)

![DC operating point B (with supply source shown)](dc_op_point_b.png)

## Observation
The transistors have non-zero drain currents and sensible VGS values. There is no obvious floating-node or completely-off transistor problem.

## Inference
The block reaches a valid DC operating point and produces a valid gate-control voltage, so it is fit to be placed in the full LDO. Its overshoot-reduction ability can only be shown in transient simulation (see the top-level transient test).
