# CFFRC (Capacitance-Free Fast-Response Circuit)

![Schematic](schematic.png)

## Device sizes

| MOS | W | L |
|---|---|---|
| M28 | 1u | 400n |
| M29 | 1u | 400n |
| M30 | 53.6u | 410n |
| M31 | 53.6u | 410n |
| M32 | 1u | 400n |
| M33 | 1u | 400n |
| M34 | 12u | 400n |
| M35 | 12u | 400n |
| M36 | 1u | 400n |
| M37 | 440n | 360n |
| M38 | 440n | 360n |
| M39 | 2u | 1u |
| M40 | 5.36u | 410n |
| M41 | 5.36u | 410n |
| M42 | 2u | 1u |
| M43–M47 | 20u | 400n |
| M48–M49 | 440n | 360n |

Capacitor: 0.5 pF.

## DC analysis

1. Check & Save, then create the symbol.
2. Create `cffrc_tb` and place the CFFRC symbol.
3. Set VDD = 3.3 V, Vref = 1.5 V, Vea = 1.5 V.
4. Launch ADE L → Analyses → Choose → `dc`.
5. Tick **Save DC Operating Point**. No sweep selected.
6. Apply → OK → Run.

Result: Spectre completed with 0 errors.

## AC analysis

1. In the testbench, open the VDD vsource. Keep source type `dc` and DC voltage 3.3 V.
2. Enable "Display small signal params". Set AC magnitude = 1, AC phase = 0°.
3. Keep Vea and Vref the same as in the DC test.
4. ADE L → Analyses → Choose → `ac`.

| Setting | Value |
|---|---|
| Sweep | Logarithmic / decade |
| Start | 1 Hz |
| Stop | 1 GHz |
| Points / decade | 20 |

5. Apply → OK, and plot the CFFRC output (Vg).

![AC setup](ac_setup.png)

## Result

![AC response](ac_response.png)

The output magnitude stays fairly constant at about 70–85 mV over most of the frequency range (a small dip near 10²–10³ Hz), which is a consistent low-frequency response. At very high frequencies (above roughly 100 MHz) the magnitude rises steeply, so the response becomes frequency-dependent near the top of the simulated range.

## Inference
The CFFRC shows a stable response over the low and mid frequency range, with an increased response at high frequency. The CFFRC is intended to give a fast path that assists the main loop during rapid output changes; its transient benefit is judged in the top-level transient test, not by this AC plot alone.
