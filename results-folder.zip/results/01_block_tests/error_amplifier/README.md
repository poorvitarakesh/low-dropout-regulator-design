# Folded-Cascode Error Amplifier

![Schematic](schematic.png)

## Device sizes (GPDK180)

| Transistor | Total width | Length | Multiplier |
|---|---|---|---|
| M0 | 39.4u | 0.4u | 8 |
| M1 | 39.4u | 0.4u | 8 |
| M2 | 2.1u | 0.4u | 1 |
| M8 | 20.15u | 0.42u | 1 |
| M9 | 20.15u | 0.42u | 1 |
| M10 | 5.36u | 0.41u | 1 |
| M11 | 5.36u | 0.41u | 1 |
| M23 | 46.11u | 0.4u | 11 |
| M24 | 1.5u | 0.4u | 1 |
| M4 | 46.11u | 0.4u | 5 |
| M5 | 46.11u | 0.4u | 5 |
| M6 | 44.815u | 0.3u | 2 |
| M7 | 44.815u | 0.3u | 2 |
| M21 | 23.05u | 0.4u | 5 |
| M22 | 46.11u | 0.4u | 1 |

## AC test setup

For AC analysis the DC voltage sources on Vin+ and Vin− were replaced with vsource and their small-signal parameters were enabled.

| Source | DC voltage | AC magnitude | AC phase |
|---|---|---|---|
| Vin+ | 1.5 V | 0.5 | 0° |
| Vin− | 1.5 V | 0.5 | 180° |

The inputs are equal and opposite, so the differential input is Vdiff = Vin+ − Vin−. The purpose was to check that the folded-cascode circuit amplifies a differential signal.

ADE L: Analyses → Choose → ac, logarithmic sweep.

| Setting | Value |
|---|---|
| Sweep type | Logarithmic |
| Start frequency | 1 Hz |
| Stop frequency | 1 GHz |
| Points per decade | 20 |

Then Apply → OK, and the output (Vea) was plotted.

![AC setup](ac_setup.png)

## Result

![AC response](ac_response.png)

| Parameter | Result |
|---|---|
| Low-frequency gain | ~168 V/V |
| Approximate gain | ~44.5 dB |
| Response | Low-pass |
| DC simulation | Successful |
| AC simulation | Successful |

## Inference
The gain is flat at about 168 V/V from 1 Hz up to roughly 1 MHz, then rolls off (the drop is steepest around 10 MHz) and is down to a few V/V by 1 GHz. It is a low-pass amplifier with ~44.5 dB DC gain, which sets how tightly the loop can force VFB onto VREF in the full LDO.
