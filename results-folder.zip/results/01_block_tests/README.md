# Block-Level Tests

Each block was simulated on its own before being connected into the full LDO.

| Block | Tests | Folder |
|---|---|---|
| Folded-cascode error amplifier | DC, AC | [error_amplifier/](error_amplifier/) |
| CFFRC | DC, AC | [cffrc/](cffrc/) |
| NFSSF | DC operating point | [nfssf/](nfssf/) |
