# Results

Everything simulated and worked out for the LDO (GPDK180, VDD = 3.3 V, VREF = 1.5 V, VOUT = 1.8 V), including every block-level test and every top-level test.

## Contents

| Folder / file | What is in it |
|---|---|
| [01_block_tests/](01_block_tests/) | Individual tests on blocks, before integration |
| &nbsp;&nbsp;[error_amplifier/](01_block_tests/error_amplifier/) | Folded-cascode error amplifier: sizes, AC setup, AC response (gain) |
| &nbsp;&nbsp;[cffrc/](01_block_tests/cffrc/) | CFFRC: sizes, DC and AC test procedure, AC response |
| &nbsp;&nbsp;[nfssf/](01_block_tests/nfssf/) | NFSSF: DC operating point |
| [02_top_level_tests/](02_top_level_tests/) | Tests on the complete LDO |
| &nbsp;&nbsp;[01_dc_operating_point.md](02_top_level_tests/01_dc_operating_point.md) | VOUT, VFB, error, load current, simulator statistics |
| &nbsp;&nbsp;[02_load_regulation.md](02_top_level_tests/02_load_regulation.md) | 10–50 mA sweep, no-load note |
| &nbsp;&nbsp;[03_line_regulation.md](02_top_level_tests/03_line_regulation.md) | VDD 2.5–3.3 V sweep, comparison with paper |
| &nbsp;&nbsp;[04_quiescent_current.md](02_top_level_tests/04_quiescent_current.md) | No-load supply current |
| &nbsp;&nbsp;[05_dropout.md](02_top_level_tests/05_dropout.md) | VDD sweep at 50 mA, 1 % criterion |
| &nbsp;&nbsp;[06_transient.md](02_top_level_tests/06_transient.md) | 10 → 50 → 10 mA load step |
| [03_theory_and_understanding.md](03_theory_and_understanding.md) | Equations and reasoning behind the design |
| [04_summary_and_inferences.md](04_summary_and_inferences.md) | Final results table, overall inferences, open issues |
| [source/LDO_report.pdf](source/LDO_report.pdf) | Original report these results came from |

## Test checklist

| # | Test | Level | Done |
|---|---|---|---|
| 1 | Error amplifier DC | Block | Yes |
| 2 | Error amplifier AC (gain) | Block | Yes |
| 3 | CFFRC DC | Block | Yes |
| 4 | CFFRC AC | Block | Yes |
| 5 | NFSSF DC operating point | Block | Yes |
| 6 | Full LDO DC operating point | Top | Yes |
| 7 | Load regulation | Top | Yes |
| 8 | Line regulation | Top | Yes |
| 9 | Quiescent current | Top | Yes |
| 10 | Dropout voltage | Top | Yes |
| 11 | Transient load response | Top | Yes |

## Headline numbers

| Metric | Result |
|---|---|
| VOUT (50 mA, VDD 3.3 V) | 1.80148 V |
| Load regulation (10–50 mA) | 0.004 mV/mA (4 mV/A) |
| Line regulation (2.5–3.3 V) | 1.35 mV/V |
| Quiescent current | 957.253 µA |
| Dropout (1 % criterion, 50 mA) | ≈ 107 mV |
| Undershoot (10 → 50 mA) | 8.66 mV (0.481 %) |
| Overshoot (50 → 10 mA) | 15.61 mV (0.867 %) |
| Total transient excursion | 24.27 mV |
| Error amplifier gain | ~168 V/V (~44.5 dB) |
