# Top-Level Tests

Tests on the complete LDO: bias circuit, folded-cascode error amplifier, CFFRC, NFSSF with overshoot stabilizer, PMOS pass transistor, feedback divider (R0/R1), output capacitor and load.

![Top-level schematic with DC operating point](images/top_level_schematic_dc_op.png)

Conditions unless stated: VDD = 3.3 V, VREF = 1.5 V, ILOAD = 50 mA.

| # | Test | File |
|---|---|---|
| 1 | DC operating point | [01_dc_operating_point.md](01_dc_operating_point.md) |
| 2 | Load regulation | [02_load_regulation.md](02_load_regulation.md) |
| 3 | Line regulation | [03_line_regulation.md](03_line_regulation.md) |
| 4 | Quiescent current | [04_quiescent_current.md](04_quiescent_current.md) |
| 5 | Dropout voltage | [05_dropout.md](05_dropout.md) |
| 6 | Transient load response | [06_transient.md](06_transient.md) |
